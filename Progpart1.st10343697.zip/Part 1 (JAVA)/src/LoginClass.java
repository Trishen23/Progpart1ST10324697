
public class LoginClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // interphase visibble
        Login take = new Login();
        take.setVisible(true);//set to visible
    }
    
}

